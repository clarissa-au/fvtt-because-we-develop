Hooks.on("setup", () => {
    CONFIG.fontDefinitions["⛺ Because We Build"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeBuild.ttf"] }]
    }
    CONFIG.fontDefinitions["⛺ Because We Connect"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeConnect.ttf"] }]
    }
    CONFIG.fontDefinitions["⛺ Because We Organize"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeOrganize.ttf"] }]
    }
    CONFIG.fontDefinitions["⛺ Because We Mentor"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeMentor.ttf"] }]
    }
    CONFIG.fontDefinitions["⛺ Because We Learn"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeLearn.ttf"] }]
    }
    CONFIG.fontDefinitions["⛺ Because We Create"] = {
        editor: true,
        fonts: [{ urls: ["/modules/fvtt-becauseWeDevelop/fonts/BecauseWeCreate.ttf"] }]
    }
});

Hooks.on('diceSoNiceReady', (dice3d) => {
    dice3d.addSystem({ id: "becauseWePerceive", name: "⛺ Because We Perceive" }, false);
    dice3d.addSystem({ id: "becauseWePerceiveSmooth", name: "⛺ Because We Perceive - Smooth" }, false);

    dice3d.addDicePreset({
        type: "d2",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d2.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d2.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "dc",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_dc.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "dc",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_dc.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d4.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d4.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d6.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d6.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "df",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_df.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "df",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_df.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d8.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d8.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d10.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d10.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d100",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d100.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d100",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d100.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d12.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d12.glb",
        system: "becauseWePerceiveSmooth"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceive/becauseWePerceive_d20.glb",
        system: "becauseWePerceive"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: "",
        modelFile: "modules/fvtt-becauseWeDevelop/model/becauseWePerceiveSmooth/becauseWePerceive_d20.glb",
        system: "becauseWePerceiveSmooth"
    });
});